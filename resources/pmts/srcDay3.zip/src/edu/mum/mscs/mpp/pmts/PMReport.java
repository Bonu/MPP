package edu.mum.mscs.mpp.pmts;

// 



public class PMReport {
	private String sprintStatus;
}
