package edu.mum.mscs.mpp.pmts;

import java.util.List;

// 



public class Developer {
	private String type;
	private List<Feature> Listoffeatures;
}
