package edu.mum.mscs.mpp.landlord;

public class FamilyHome {
	private double rent;
		
	
	public FamilyHome(double rent) {
		super();
		this.rent = rent;
		}
	
	public double getrent(){
		return rent;
	}
	
	

	

}
