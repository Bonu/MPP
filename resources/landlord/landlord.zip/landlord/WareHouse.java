package edu.mum.mscs.mpp.landlord;

public class WareHouse {

	private double rent;

	
	public WareHouse(double rent) {
		super();
		this.rent = rent;
		
	}
	
	public double getrent(){
		return rent;
	}
	
	

}
