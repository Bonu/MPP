package edu.mum.mscs.mpp.landlord;

public class RentalProperty {

}
