package edu.mum.mscs.mpp.landlord;

public class Farmland {

	private double rent;
	
	public Farmland(double rent) {
		super();
		this.rent = rent;
		
	}
	
	public double getrent(){
		return rent;
	}
	

	
	
	

	
}
